<?php
$onepeyurl = "https://1pey.com";
$apiurl = $onepeyurl;
$api_initialRequestUri = '/transaction/execute';
$api_redirectCustomerUri = '/transaction/customer';
$sslport = 443;
$verifypeer = 1;
$verifyhost = 2;
?>