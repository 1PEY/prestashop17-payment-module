$(document).ready(function() {
    $("#payment-option-1").attr('checked','checked');
});